<template>
  <div id="info" class="mt-5">
    <h2 class="h5 text-center">ANNONCE D'INFORMATION</h2>
    <div class="mt-3 container text-center">
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Neque in itaque pariatur tenetur amet nemo eos, minus saepe aperiam provident voluptate, ea, vitae mollitia? Molestias natus placeat consectetur incidunt sed?</p>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Neque in itaque pariatur tenetur amet nemo eos, minus saepe aperiam provident voluptate, ea, vitae mollitia? Molestias natus placeat consectetur incidunt sed?</p>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Neque in itaque pariatur tenetur amet nemo eos, minus saepe aperiam provident voluptate, ea, vitae mollitia? Molestias natus placeat consectetur incidunt sed?</p>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Neque in itaque pariatur tenetur amet nemo eos, minus saepe aperiam provident voluptate, ea, vitae mollitia? Molestias natus placeat consectetur incidunt sed?</p>
    </div>
    <div class="container text-center">
        <router-link class="btn btn-secondary" to="/">REVENIR A l'ACCUEIL</router-link>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Info'
}
</script>

<style>

</style>