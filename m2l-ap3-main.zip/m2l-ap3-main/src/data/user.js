// Création des données de ligue
const user = [
  {
    id: 1,
    nom: 'DODDE',
    prenom: 'Cédrik',
    rue: '10 Avenue Marc SANGNIER',
    cp: 91170,
    ville: 'Viry-Châtillon',
    email: 'jharold613@gmail.com',
    mdp: 'riky',
    role: 'admin'
  },
  {
    id: 2,
    nom: 'PHI KI PHONG',
    prenom: 'Lise',
    rue: 'Adresse X',
    cp: 93001,
    ville: 'Ville X',
    email: 'lise@gmail.com',
    mdp: 'lise',
    role: 'adherent'
  },
  {
    id: 3,
    nom: 'FAMILLE',
    prenom: 'Kath',
    rue: 'Adresse Y',
    cp: 75000,
    ville: 'Ville Y',
    email: 'kath@gmail.com',
    mdp: 'kath',
    role: 'tresorier'
  }
]

// Exportation du tableau en forme de module
module.exports = user