<template>
  <div class="about">
    <h1>This is an about page</h1>

    <button class="btn btn-success">Mon booton boostrap</button>
  </div>
</template>